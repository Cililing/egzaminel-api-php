CREATE TRIGGER exam_date
BEFORE INSERT ON exams
FOR EACH ROW
  SET NEW.last_update = NOW();
