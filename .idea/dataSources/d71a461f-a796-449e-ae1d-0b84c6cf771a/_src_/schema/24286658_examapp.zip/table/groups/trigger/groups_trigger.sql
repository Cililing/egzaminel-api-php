CREATE TRIGGER groups_trigger
BEFORE INSERT ON groups
FOR EACH ROW
  SET NEW.last_update = NOW();
