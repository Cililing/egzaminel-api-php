CREATE TRIGGER terms_date
BEFORE INSERT ON terms
FOR EACH ROW
  SET NEW.last_update = NOW();
